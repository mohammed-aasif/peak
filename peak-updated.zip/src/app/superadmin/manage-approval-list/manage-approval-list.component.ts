import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-approval-list',
  templateUrl: './manage-approval-list.component.html',
  styleUrls: ['./manage-approval-list.component.css']
})
export class ManageApprovalListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
